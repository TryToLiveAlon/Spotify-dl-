// index.js

module.exports = (req, res) => {
  res.status(200).send("The SpotifyDL service is live!");
};
